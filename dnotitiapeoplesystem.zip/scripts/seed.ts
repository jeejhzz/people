import fs from "fs";
import path from "path";
import { importSnapshot } from "../src/lib/importExcel";

const SNAPSHOT_DATE = process.argv[2] ?? "2026-07-01";
const filePath = path.join(process.cwd(), "data", "employees_source.xlsx");

const buffer = fs.readFileSync(filePath);
const result = importSnapshot(buffer, SNAPSHOT_DATE, "초기 시딩 (엑셀 원본)");

console.log(JSON.stringify(result, null, 2));
