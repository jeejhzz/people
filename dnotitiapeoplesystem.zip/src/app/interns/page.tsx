"use client";

import { useEffect, useState } from "react";
import { RosterTable, RosterRow, downloadCsv } from "@/components/RosterTable";

const TODAY = new Date().toISOString().slice(0, 10);

function daysUntil(dateStr: string, asOf: string): number {
  return Math.round(
    (new Date(dateStr).getTime() - new Date(asOf).getTime()) / (1000 * 60 * 60 * 24)
  );
}

export default function InternsPage() {
  const [asOf, setAsOf] = useState(TODAY);
  const [roster, setRoster] = useState<RosterRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => r.json())
      .then((m) => {
        if (m.latestSnapshotDate) setAsOf(m.latestSnapshotDate);
      });
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/employees?asOf=${asOf}&isIntern=true`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setRoster(d.roster);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [asOf]);

  const endingSoon = roster.filter(
    (r) => r.contract_end_date && daysUntil(r.contract_end_date, asOf) <= 30 && daysUntil(r.contract_end_date, asOf) >= 0
  );

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-semibold">인턴 현황</h1>
          <p className="text-sm text-neutral-500 mt-0.5">
            기준일자: {asOf} · 총 {loading ? "…" : roster.length}명
          </p>
        </div>
        <input
          type="date"
          value={asOf}
          onChange={(e) => setAsOf(e.target.value)}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        />
      </div>

      {endingSoon.length > 0 && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <h3 className="text-sm font-medium text-amber-800 mb-2">
            계약종료 임박 (30일 이내) · {endingSoon.length}명
          </h3>
          <ul className="text-sm text-amber-900 space-y-1">
            {endingSoon.map((r) => (
              <li key={r.emp_no}>
                {r.name} ({[r.division, r.group_name, r.department].filter(Boolean).join(" · ")}) —{" "}
                {r.contract_end_date} 종료 (D-{daysUntil(r.contract_end_date!, asOf)})
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={() => downloadCsv(roster, `인턴명단_${asOf}.csv`)}
          disabled={roster.length === 0}
          className="px-3 py-1.5 text-sm rounded-md border border-neutral-300 bg-white hover:border-neutral-400 disabled:opacity-40"
        >
          CSV 내보내기
        </button>
      </div>

      <RosterTable rows={roster} />
    </div>
  );
}
