import { NextRequest, NextResponse } from "next/server";
import { importSnapshot } from "@/lib/importExcel";

export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const file = formData.get("file");
  const snapshotDate = formData.get("snapshotDate");
  const note = formData.get("note");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "파일이 없습니다." }, { status: 400 });
  }
  if (typeof snapshotDate !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(snapshotDate)) {
    return NextResponse.json(
      { error: "기준일자(snapshotDate)를 YYYY-MM-DD 형식으로 입력하세요." },
      { status: 400 }
    );
  }

  const buffer = Buffer.from(await file.arrayBuffer());

  try {
    const result = importSnapshot(
      buffer,
      snapshotDate,
      typeof note === "string" ? note : undefined
    );
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "업로드 처리 중 오류가 발생했습니다." },
      { status: 500 }
    );
  }
}
