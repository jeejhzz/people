import { NextRequest, NextResponse } from "next/server";
import { buildOrgTree, getEmployeesAsOf, getLatestSnapshotDate } from "@/lib/queries";
import { getDb } from "@/lib/db";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const asOf = sp.get("asOf") || getLatestSnapshotDate() || new Date().toISOString().slice(0, 10);

  const employees = getEmployeesAsOf({ asOf });
  const tree = buildOrgTree(employees);

  // Recent-hire highlighting: anyone whose hire_date falls within the last 2
  // months relative to asOf, based on the excel legend (초록=신규입사).
  const cutoff = new Date(asOf);
  cutoff.setMonth(cutoff.getMonth() - 2);
  const cutoffISO = cutoff.toISOString().slice(0, 10);

  const db = getDb();
  const movedEmpNos = new Set(
    (
      db
        .prepare(
          `SELECT DISTINCT emp_no FROM employee_history WHERE change_type='부서이동' AND snapshot_date >= ?`
        )
        .all(cutoffISO) as { emp_no: string }[]
    ).map((r) => r.emp_no)
  );

  const annotate = (node: import("@/lib/queries").OrgNode): unknown => ({
    ...node,
    members: node.members.map((m) => ({
      ...m,
      isRecentHire: m.hire_date >= cutoffISO,
      isMoved: movedEmpNos.has(m.emp_no),
      isIntern: m.category === "인턴",
    })),
    children: node.children.map(annotate),
  });

  return NextResponse.json({ asOf, tree: tree.map(annotate) });
}
