import { NextRequest, NextResponse } from "next/server";
import { computeAge, computeTenureYears, getEmployeesAsOf, getLatestSnapshotDate } from "@/lib/queries";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const asOf = sp.get("asOf") || getLatestSnapshotDate() || new Date().toISOString().slice(0, 10);

  const employees = getEmployeesAsOf({
    asOf,
    division: sp.get("division") || undefined,
    groupName: sp.get("groupName") || undefined,
    department: sp.get("department") || undefined,
    category: sp.get("category") || undefined,
    researcherType: sp.get("researcherType") || undefined,
    isIntern: sp.get("isIntern") === "true",
    ageMax: sp.get("ageMax") ? Number(sp.get("ageMax")) : undefined,
    ageMin: sp.get("ageMin") ? Number(sp.get("ageMin")) : undefined,
    hireYear: sp.get("hireYear") ? Number(sp.get("hireYear")) : undefined,
    nationality: sp.get("nationality") || undefined,
    gender: sp.get("gender") || undefined,
  });

  const roster = employees
    .map((e) => ({
      ...e,
      age: computeAge(e.birth_date, asOf),
      tenureYears: computeTenureYears(e.hire_date, asOf),
    }))
    .sort((a, b) => a.seq - b.seq);

  return NextResponse.json({ asOf, count: roster.length, roster });
}
