import { NextRequest, NextResponse } from "next/server";
import { computeAge, computeTenureYears, getEmployeesAsOf, getLatestSnapshotDate } from "@/lib/queries";

function countBy<T>(items: T[], keyFn: (t: T) => string): { name: string; value: number }[] {
  const map = new Map<string, number>();
  for (const item of items) {
    const k = keyFn(item);
    map.set(k, (map.get(k) ?? 0) + 1);
  }
  return Array.from(map.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const asOf = sp.get("asOf") || getLatestSnapshotDate() || new Date().toISOString().slice(0, 10);

  const employees = getEmployeesAsOf({ asOf });

  const ageBuckets = [
    { label: "~25", min: 0, max: 25 },
    { label: "26-30", min: 26, max: 30 },
    { label: "31-35", min: 31, max: 35 },
    { label: "36-40", min: 36, max: 40 },
    { label: "41-45", min: 41, max: 45 },
    { label: "46-50", min: 46, max: 50 },
    { label: "51~", min: 51, max: 200 },
  ];
  const ages = employees.map((e) => computeAge(e.birth_date, asOf));
  const ageDistribution = ageBuckets.map((b) => ({
    name: b.label,
    value: ages.filter((a) => a >= b.min && a <= b.max).length,
  }));

  const tenureBuckets = [
    { label: "<1년", min: 0, max: 1 },
    { label: "1-2년", min: 1, max: 2 },
    { label: "2-3년", min: 2, max: 3 },
    { label: "3-5년", min: 3, max: 5 },
    { label: "5년+", min: 5, max: 200 },
  ];
  const tenures = employees.map((e) => computeTenureYears(e.hire_date, asOf));
  const tenureDistribution = tenureBuckets.map((b) => ({
    name: b.label,
    value: tenures.filter((t) => t >= b.min && t < b.max).length,
  }));

  const byDivision = countBy(employees, (e) => e.division);
  const byGroup = countBy(
    employees.filter((e) => e.group_name),
    (e) => `${e.division} · ${e.group_name}`
  );
  const byDepartment = countBy(employees, (e) => `${e.division} · ${e.department}`);
  const byCategory = countBy(employees, (e) => e.category);
  const byResearcherType = countBy(employees, (e) => e.researcher_type ?? "미분류");
  const byGender = countBy(employees, (e) => e.gender ?? "미상");
  const byNationality = countBy(employees, (e) => e.nationality ?? "미상");

  const hireYearCounts = countBy(
    employees.filter((e) => e.hire_date <= asOf),
    (e) => String(new Date(e.hire_date).getFullYear())
  ).sort((a, b) => a.name.localeCompare(b.name));

  return NextResponse.json({
    asOf,
    total: employees.length,
    byDivision,
    byGroup,
    byDepartment,
    byCategory,
    byResearcherType,
    byGender,
    byNationality,
    ageDistribution,
    tenureDistribution,
    hireYearCounts,
  });
}
