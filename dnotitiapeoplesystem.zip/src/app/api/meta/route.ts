import { NextResponse } from "next/server";
import { getAllEmployees, getLatestSnapshotDate, getSnapshots } from "@/lib/queries";

export async function GET() {
  const employees = getAllEmployees();
  const unique = (arr: (string | null)[]) =>
    Array.from(new Set(arr.filter((v): v is string => !!v))).sort();

  return NextResponse.json({
    latestSnapshotDate: getLatestSnapshotDate(),
    snapshots: getSnapshots(),
    divisions: unique(employees.map((e) => e.division)),
    groups: unique(employees.map((e) => e.group_name)),
    departments: unique(employees.map((e) => e.department)),
    categories: unique(employees.map((e) => e.category)),
    researcherTypes: unique(employees.map((e) => e.researcher_type)),
    nationalities: unique(employees.map((e) => e.nationality)),
  });
}
