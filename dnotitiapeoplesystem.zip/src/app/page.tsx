"use client";

import { useEffect, useState } from "react";
import { CategoricalBarChart, ChartDatum, HorizontalBarChart, StatTile } from "@/components/charts";

interface DashboardData {
  asOf: string;
  total: number;
  byDivision: ChartDatum[];
  byGroup: ChartDatum[];
  byDepartment: ChartDatum[];
  byCategory: ChartDatum[];
  byResearcherType: ChartDatum[];
  byGender: ChartDatum[];
  byNationality: ChartDatum[];
  ageDistribution: ChartDatum[];
  tenureDistribution: ChartDatum[];
  hireYearCounts: ChartDatum[];
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-neutral-200 bg-white p-4">
      <h3 className="text-sm font-medium text-neutral-700 mb-3">{title}</h3>
      {children}
    </div>
  );
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [asOf, setAsOf] = useState<string>("");

  useEffect(() => {
    const url = asOf ? `/api/dashboard?asOf=${asOf}` : "/api/dashboard";
    fetch(url)
      .then((r) => r.json())
      .then((d: DashboardData) => {
        setData(d);
        if (!asOf) setAsOf(d.asOf);
      });
  }, [asOf]);

  if (!data) return <div className="text-sm text-neutral-500">불러오는 중…</div>;

  const internCount = data.byCategory.find((c) => c.name === "인턴")?.value ?? 0;
  const researcherCount = data.byResearcherType.find((c) => c.name === "R&D")?.value ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-semibold">조직별 현황 대시보드</h1>
          <p className="text-sm text-neutral-500 mt-0.5">기준일자: {data.asOf}</p>
        </div>
        <input
          type="date"
          value={asOf}
          onChange={(e) => setAsOf(e.target.value)}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatTile label="전체 인원" value={data.total} sub="재직 기준" />
        <StatTile label="연구원(R&D)" value={researcherCount} sub={`전체의 ${Math.round((researcherCount / data.total) * 100)}%`} />
        <StatTile label="인턴" value={internCount} />
        <StatTile
          label="올해 입사"
          value={
            data.hireYearCounts.find((h) => h.name === String(new Date(data.asOf).getFullYear()))
              ?.value ?? 0
          }
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card title="본부별 인원">
          <CategoricalBarChart data={data.byDivision} />
        </Card>
        <Card title="분류별 인원">
          <CategoricalBarChart data={data.byCategory} />
        </Card>
        <Card title="그룹별 인원">
          <HorizontalBarChart data={data.byGroup} />
        </Card>
        <Card title="부서별 인원">
          <HorizontalBarChart data={data.byDepartment} />
        </Card>
        <Card title="연령 분포">
          <CategoricalBarChart data={data.ageDistribution} />
        </Card>
        <Card title="연차 분포">
          <CategoricalBarChart data={data.tenureDistribution} />
        </Card>
        <Card title="연구원 구분 (R&D / N-R&D)">
          <CategoricalBarChart data={data.byResearcherType} />
        </Card>
        <Card title="성별 구성">
          <CategoricalBarChart data={data.byGender} />
        </Card>
        <Card title="연도별 입사 인원">
          <HorizontalBarChart data={data.hireYearCounts} />
        </Card>
        <Card title="국적">
          <CategoricalBarChart data={data.byNationality} />
        </Card>
      </div>
    </div>
  );
}
