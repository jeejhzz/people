"use client";

import { useEffect, useMemo, useState } from "react";
import { RosterTable, RosterRow, downloadCsv } from "@/components/RosterTable";

interface Meta {
  latestSnapshotDate: string | null;
  divisions: string[];
  groups: string[];
  departments: string[];
  categories: string[];
  researcherTypes: string[];
  nationalities: string[];
}

const TODAY = new Date().toISOString().slice(0, 10);

const PRESETS = [
  { key: "all", label: "전체 재직 인원" },
  { key: "researchers", label: "연구원(R&D) 현황" },
  { key: "under30", label: "만 30세 이하" },
  { key: "thisYearHires", label: "올해 입사자" },
  { key: "interns", label: "인턴 현황" },
];

export default function QueryPage() {
  const [meta, setMeta] = useState<Meta | null>(null);
  const [asOf, setAsOf] = useState(TODAY);
  const [division, setDivision] = useState("");
  const [category, setCategory] = useState("");
  const [researcherType, setResearcherType] = useState("");
  const [isIntern, setIsIntern] = useState(false);
  const [ageMax, setAgeMax] = useState("");
  const [ageMin, setAgeMin] = useState("");
  const [hireYear, setHireYear] = useState("");
  const [roster, setRoster] = useState<RosterRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [preset, setPreset] = useState("all");

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => r.json())
      .then((m: Meta) => {
        setMeta(m);
        if (m.latestSnapshotDate) setAsOf(m.latestSnapshotDate);
      });
  }, []);

  const applyPreset = (key: string) => {
    setPreset(key);
    setDivision("");
    setCategory("");
    setResearcherType("");
    setIsIntern(false);
    setAgeMax("");
    setAgeMin("");
    setHireYear("");
    if (key === "researchers") setResearcherType("R&D");
    if (key === "under30") setAgeMax("30");
    if (key === "thisYearHires") setHireYear(String(new Date(asOf).getFullYear()));
    if (key === "interns") setIsIntern(true);
  };

  const queryString = useMemo(() => {
    const sp = new URLSearchParams();
    sp.set("asOf", asOf);
    if (division) sp.set("division", division);
    if (category) sp.set("category", category);
    if (researcherType) sp.set("researcherType", researcherType);
    if (isIntern) sp.set("isIntern", "true");
    if (ageMax) sp.set("ageMax", ageMax);
    if (ageMin) sp.set("ageMin", ageMin);
    if (hireYear) sp.set("hireYear", hireYear);
    return sp.toString();
  }, [asOf, division, category, researcherType, isIntern, ageMax, ageMin, hireYear]);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/employees?${queryString}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setRoster(d.roster);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [queryString]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-semibold">인원 조회</h1>
        <p className="text-sm text-neutral-500 mt-0.5">
          기준일자와 조건을 선택하면 해당 인원 수와 명단을 바로 확인할 수 있습니다.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.key}
            onClick={() => applyPreset(p.key)}
            className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${
              preset === p.key
                ? "bg-neutral-900 text-white border-neutral-900"
                : "bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400"
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          기준일자
          <input
            type="date"
            value={asOf}
            onChange={(e) => {
              setAsOf(e.target.value);
              setPreset("custom");
            }}
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          />
        </label>
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          본부
          <select
            value={division}
            onChange={(e) => {
              setDivision(e.target.value);
              setPreset("custom");
            }}
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          >
            <option value="">전체</option>
            {meta?.divisions.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          분류
          <select
            value={category}
            onChange={(e) => {
              setCategory(e.target.value);
              setPreset("custom");
            }}
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          >
            <option value="">전체</option>
            {meta?.categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          연구원 구분
          <select
            value={researcherType}
            onChange={(e) => {
              setResearcherType(e.target.value);
              setPreset("custom");
            }}
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          >
            <option value="">전체</option>
            {meta?.researcherTypes.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          나이(만) 이하
          <input
            type="number"
            value={ageMax}
            onChange={(e) => {
              setAgeMax(e.target.value);
              setPreset("custom");
            }}
            placeholder="예: 30"
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          />
        </label>
        <label className="text-xs text-neutral-500 flex flex-col gap-1">
          입사연도
          <input
            type="number"
            value={hireYear}
            onChange={(e) => {
              setHireYear(e.target.value);
              setPreset("custom");
            }}
            placeholder="예: 2026"
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm text-neutral-900"
          />
        </label>
      </div>

      <div className="flex items-center justify-between">
        <div className="text-sm">
          <span className="font-semibold text-base">{loading ? "…" : roster.length}</span>
          <span className="text-neutral-500"> 명 ({asOf} 기준)</span>
        </div>
        <button
          onClick={() => downloadCsv(roster, `인원명단_${asOf}.csv`)}
          disabled={roster.length === 0}
          className="px-3 py-1.5 text-sm rounded-md border border-neutral-300 bg-white hover:border-neutral-400 disabled:opacity-40"
        >
          CSV 내보내기
        </button>
      </div>

      <RosterTable rows={roster} />
    </div>
  );
}
