"use client";

import { useEffect, useState } from "react";
import { OrgChart, OrgNodeData } from "@/components/OrgChart";

const TODAY = new Date().toISOString().slice(0, 10);

export default function OrgChartPage() {
  const [asOf, setAsOf] = useState(TODAY);
  const [tree, setTree] = useState<OrgNodeData[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => r.json())
      .then((m) => {
        if (m.latestSnapshotDate) setAsOf(m.latestSnapshotDate);
      });
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/orgtree?asOf=${asOf}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setTree(d.tree);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [asOf]);

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-semibold">조직도</h1>
          <p className="text-sm text-neutral-500 mt-0.5">
            엑셀 데이터에서 자동으로 생성된 조직도입니다. 기준일자: {asOf}
          </p>
        </div>
        <input
          type="date"
          value={asOf}
          onChange={(e) => setAsOf(e.target.value)}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        />
      </div>
      {loading && <div className="text-sm text-neutral-500">불러오는 중…</div>}
      {tree && <OrgChart tree={tree} />}
    </div>
  );
}
