"use client";

import { useState } from "react";

interface UploadResult {
  snapshotDate: string;
  total: number;
  newHires: number;
  moved: number;
  reactivated: number;
  deactivated: number;
  errors: string[];
}

export default function UploadPage() {
  const [snapshotDate, setSnapshotDate] = useState(new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<UploadResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!file) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const fd = new FormData();
      fd.set("file", file);
      fd.set("snapshotDate", snapshotDate);
      fd.set("note", note);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "업로드 실패");
      } else {
        setResult(data);
      }
    } catch {
      setError("업로드 중 오류가 발생했습니다.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="text-lg font-semibold">인원 데이터 업로드</h1>
        <p className="text-sm text-neutral-500 mt-0.5">
          &ldquo;■ 임직원 현황&rdquo; 형식의 엑셀 파일(사번, 이름, 분류, 상위조직1/2, 부서, 직책, 생년월일,
          성별, 입사일, 계약종료일, 연구원 구분 등 컬럼 포함)을 업로드하면 인원 정보가 갱신됩니다.
          기존 사번은 최신 정보로 덮어쓰고, 이번 업로드에 없는 사번은 퇴사 처리(비활성)됩니다.
        </p>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4 space-y-4">
        <label className="flex flex-col gap-1 text-sm">
          기준일자 (엑셀 상단의 &lsquo;기준&rsquo; 날짜)
          <input
            type="date"
            value={snapshotDate}
            onChange={(e) => setSnapshotDate(e.target.value)}
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          메모 (선택)
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="예: 2026년 7월 정기 갱신"
            className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          엑셀 파일
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="text-sm"
          />
        </label>
        <button
          onClick={submit}
          disabled={!file || busy}
          className="px-4 py-2 text-sm rounded-md bg-neutral-900 text-white disabled:opacity-40"
        >
          {busy ? "업로드 중…" : "업로드"}
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      {result && (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900 space-y-1">
          <div className="font-medium">업로드 완료 ({result.snapshotDate})</div>
          <div>총 인원: {result.total}명</div>
          <div>신규입사: {result.newHires}명 · 부서이동: {result.moved}명 · 복귀: {result.reactivated}명 · 퇴사 처리: {result.deactivated}명</div>
          {result.errors.length > 0 && (
            <div className="mt-2 text-amber-700">
              <div className="font-medium">건너뛴 행 ({result.errors.length}건)</div>
              <ul className="list-disc list-inside">
                {result.errors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
