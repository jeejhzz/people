import * as XLSX from "xlsx";
import { getDb } from "./db";

export interface ParsedEmployee {
  seq: number;
  empNo: string;
  name: string;
  category: string;
  division: string;
  groupName: string | null;
  department: string;
  title: string | null;
  birthDate: string;
  gender: string | null;
  hireDate: string;
  workStartDate: string | null;
  contractEndDate: string | null;
  regularConversionDate: string | null;
  nationality: string | null;
  researcherType: string | null;
}

export interface ImportResult {
  snapshotDate: string;
  total: number;
  newHires: number;
  moved: number;
  reactivated: number;
  deactivated: number;
  errors: string[];
}

const HEADER_MAP: Record<string, keyof ParsedEmployee | "skip"> = {
  "구분": "seq",
  "사번": "empNo",
  "이름": "name",
  "분류": "category",
  "상위조직1": "division",
  "상위조직2": "groupName",
  "부서": "department",
  "직책": "title",
  "생년월일": "birthDate",
  "나이(만)": "skip",
  "연차": "skip",
  "성별": "gender",
  "입사일": "hireDate",
  "근로시작일": "workStartDate",
  "계약종료일": "contractEndDate",
  "정규직전환일": "regularConversionDate",
  "국적": "nationality",
  "연구원": "researcherType",
};

function excelDateToISO(value: unknown): string | null {
  if (value == null || value === "") return null;
  if (value instanceof Date) {
    return value.toISOString().slice(0, 10);
  }
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (!parsed) return null;
    const mm = String(parsed.m).padStart(2, "0");
    const dd = String(parsed.d).padStart(2, "0");
    return `${parsed.y}-${mm}-${dd}`;
  }
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed || trimmed === "#REF!") return null;
    const d = new Date(trimmed);
    if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
    return null;
  }
  return null;
}

export function parseWorkbook(buffer: Buffer): {
  employees: ParsedEmployee[];
  errors: string[];
} {
  const wb = XLSX.read(buffer, { type: "buffer", cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    raw: true,
    defval: null,
  });

  // Header row is the first row that contains "사번"
  const headerRowIdx = rows.findIndex((r) => r.includes("사번"));
  if (headerRowIdx === -1) {
    return { employees: [], errors: ["헤더 행을 찾을 수 없습니다 ('사번' 컬럼 없음)."] };
  }
  const headerRow = rows[headerRowIdx] as string[];
  const colIndex: Record<string, number> = {};
  headerRow.forEach((h, i) => {
    if (h && HEADER_MAP[h]) colIndex[h] = i;
  });

  const errors: string[] = [];
  const employees: ParsedEmployee[] = [];

  for (let i = headerRowIdx + 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every((v) => v == null || v === "")) continue;
    const nameIdx = colIndex["이름"];
    const name = nameIdx != null ? row[nameIdx] : null;
    if (!name) continue;

    const empNo = String(row[colIndex["사번"]] ?? "").trim();
    if (!empNo) {
      errors.push(`행 ${i + 1}: 사번이 없어 건너뜀 (${name})`);
      continue;
    }

    const birthDate = excelDateToISO(row[colIndex["생년월일"]]);
    const hireDate = excelDateToISO(row[colIndex["입사일"]]);
    if (!birthDate || !hireDate) {
      errors.push(`행 ${i + 1}: 생년월일 또는 입사일이 없어 건너뜀 (${name})`);
      continue;
    }

    employees.push({
      seq: Number(row[colIndex["구분"]] ?? 0),
      empNo,
      name: String(name).trim(),
      category: String(row[colIndex["분류"]] ?? "").trim(),
      division: String(row[colIndex["상위조직1"]] ?? "").trim(),
      groupName: row[colIndex["상위조직2"]]
        ? String(row[colIndex["상위조직2"]]).trim()
        : null,
      department: String(row[colIndex["부서"]] ?? "").trim(),
      title: row[colIndex["직책"]] ? String(row[colIndex["직책"]]).trim() : null,
      birthDate,
      gender: row[colIndex["성별"]] ? String(row[colIndex["성별"]]).trim() : null,
      hireDate,
      workStartDate: excelDateToISO(row[colIndex["근로시작일"]]),
      contractEndDate: excelDateToISO(row[colIndex["계약종료일"]]),
      regularConversionDate: excelDateToISO(row[colIndex["정규직전환일"]]),
      nationality: row[colIndex["국적"]]
        ? String(row[colIndex["국적"]]).trim()
        : null,
      researcherType: row[colIndex["연구원"]]
        ? String(row[colIndex["연구원"]]).trim()
        : null,
    });
  }

  return { employees, errors };
}

export function importSnapshot(
  buffer: Buffer,
  snapshotDate: string,
  note?: string
): ImportResult {
  const { employees, errors } = parseWorkbook(buffer);
  const db = getDb();

  let newHires = 0;
  let moved = 0;
  let reactivated = 0;
  let deactivated = 0;

  const txn = db.transaction(() => {
    const existingByEmpNo = new Map(
      (
        db
          .prepare(
            `SELECT emp_no, division, group_name, department, is_active FROM employees`
          )
          .all() as {
          emp_no: string;
          division: string;
          group_name: string | null;
          department: string;
          is_active: number;
        }[]
      ).map((r) => [r.emp_no, r])
    );

    const seenEmpNos = new Set<string>();

    const upsert = db.prepare(`
      INSERT INTO employees (
        seq, emp_no, name, category, division, group_name, department, title,
        birth_date, gender, hire_date, work_start_date, contract_end_date,
        regular_conversion_date, nationality, researcher_type,
        is_active, first_snapshot_date, last_snapshot_date, inactive_since, updated_at
      ) VALUES (
        @seq, @empNo, @name, @category, @division, @groupName, @department, @title,
        @birthDate, @gender, @hireDate, @workStartDate, @contractEndDate,
        @regularConversionDate, @nationality, @researcherType,
        1, @snapshotDate, @snapshotDate, NULL, datetime('now')
      )
      ON CONFLICT(emp_no) DO UPDATE SET
        seq=excluded.seq, name=excluded.name, category=excluded.category,
        division=excluded.division, group_name=excluded.group_name,
        department=excluded.department, title=excluded.title,
        birth_date=excluded.birth_date, gender=excluded.gender,
        hire_date=excluded.hire_date, work_start_date=excluded.work_start_date,
        contract_end_date=excluded.contract_end_date,
        regular_conversion_date=excluded.regular_conversion_date,
        nationality=excluded.nationality, researcher_type=excluded.researcher_type,
        is_active=1, last_snapshot_date=@snapshotDate, inactive_since=NULL,
        updated_at=datetime('now')
    `);

    const insertHistory = db.prepare(`
      INSERT INTO employee_history (emp_no, name, division, group_name, department, title, snapshot_date, change_type)
      VALUES (@empNo, @name, @division, @groupName, @department, @title, @snapshotDate, @changeType)
    `);

    for (const emp of employees) {
      seenEmpNos.add(emp.empNo);
      const prev = existingByEmpNo.get(emp.empNo);

      upsert.run({ ...emp, snapshotDate });

      if (!prev) {
        newHires++;
        insertHistory.run({
          empNo: emp.empNo,
          name: emp.name,
          division: emp.division,
          groupName: emp.groupName,
          department: emp.department,
          title: emp.title,
          snapshotDate,
          changeType: "신규입사",
        });
      } else if (prev.is_active === 0) {
        reactivated++;
        insertHistory.run({
          empNo: emp.empNo,
          name: emp.name,
          division: emp.division,
          groupName: emp.groupName,
          department: emp.department,
          title: emp.title,
          snapshotDate,
          changeType: "복귀",
        });
      } else if (
        prev.division !== emp.division ||
        prev.group_name !== emp.groupName ||
        prev.department !== emp.department
      ) {
        moved++;
        insertHistory.run({
          empNo: emp.empNo,
          name: emp.name,
          division: emp.division,
          groupName: emp.groupName,
          department: emp.department,
          title: emp.title,
          snapshotDate,
          changeType: "부서이동",
        });
      }
    }

    const deactivate = db.prepare(`
      UPDATE employees SET is_active = 0, inactive_since = @snapshotDate, updated_at = datetime('now')
      WHERE emp_no = @empNo AND is_active = 1
    `);
    for (const [empNo, prev] of existingByEmpNo) {
      if (!seenEmpNos.has(empNo) && prev.is_active === 1) {
        deactivate.run({ empNo, snapshotDate });
        deactivated++;
      }
    }

    db.prepare(
      `INSERT INTO snapshots (snapshot_date, employee_count, note)
       VALUES (@snapshotDate, @count, @note)
       ON CONFLICT(snapshot_date) DO UPDATE SET employee_count=@count, note=@note, uploaded_at=datetime('now')`
    ).run({ snapshotDate, count: employees.length, note: note ?? null });
  });

  txn();

  return {
    snapshotDate,
    total: employees.length,
    newHires,
    moved,
    reactivated,
    deactivated,
    errors,
  };
}
