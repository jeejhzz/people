import { getDb } from "./db";

export interface Employee {
  id: number;
  seq: number;
  emp_no: string;
  name: string;
  category: string;
  division: string;
  group_name: string | null;
  department: string;
  title: string | null;
  birth_date: string;
  gender: string | null;
  hire_date: string;
  work_start_date: string | null;
  contract_end_date: string | null;
  regular_conversion_date: string | null;
  nationality: string | null;
  researcher_type: string | null;
  is_active: number;
  first_snapshot_date: string;
  last_snapshot_date: string;
  inactive_since: string | null;
}

export interface AsOfFilters {
  asOf: string; // YYYY-MM-DD
  division?: string;
  groupName?: string;
  department?: string;
  category?: string;
  researcherType?: string;
  isIntern?: boolean;
  ageMax?: number;
  ageMin?: number;
  hireYear?: number;
  nationality?: string;
  gender?: string;
}

export function computeAge(birthDateISO: string, asOfISO: string): number {
  const birth = new Date(birthDateISO);
  const asOf = new Date(asOfISO);
  let age = asOf.getFullYear() - birth.getFullYear();
  const monthDiff = asOf.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && asOf.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export function computeTenureYears(hireDateISO: string, asOfISO: string): number {
  const hire = new Date(hireDateISO);
  const asOf = new Date(asOfISO);
  const ms = asOf.getTime() - hire.getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24 * 365.25) * 10) / 10;
}

/** Whether the employee is considered active/present on the given date.
 *
 * For dates within an uploaded snapshot's coverage, snapshot membership is the
 * ground truth (contract_end_date can be stale — e.g. a contract that was
 * renewed after the field was last recorded — so it's ignored there). Only when
 * projecting past the most recent snapshot do we fall back to contract_end_date
 * as a best-effort forecast, since no newer snapshot confirms who's still on. */
export function isActiveAsOf(emp: Employee, asOfISO: string): boolean {
  if (emp.hire_date > asOfISO) return false;
  if (emp.is_active === 0 && emp.inactive_since && asOfISO >= emp.inactive_since) {
    return false;
  }
  if (asOfISO > emp.last_snapshot_date) {
    if (emp.contract_end_date && emp.contract_end_date < asOfISO) return false;
  }
  return true;
}

export function getAllEmployees(): Employee[] {
  const db = getDb();
  return db.prepare(`SELECT * FROM employees ORDER BY seq`).all() as Employee[];
}

export function getEmployeesAsOf(filters: AsOfFilters): Employee[] {
  const all = getAllEmployees();
  return all.filter((emp) => {
    if (!isActiveAsOf(emp, filters.asOf)) return false;
    if (filters.division && emp.division !== filters.division) return false;
    if (filters.groupName && emp.group_name !== filters.groupName) return false;
    if (filters.department && emp.department !== filters.department) return false;
    if (filters.category && emp.category !== filters.category) return false;
    if (filters.researcherType && emp.researcher_type !== filters.researcherType)
      return false;
    if (filters.isIntern && emp.category !== "인턴") return false;
    if (filters.nationality && emp.nationality !== filters.nationality) return false;
    if (filters.gender && emp.gender !== filters.gender) return false;
    if (filters.hireYear && new Date(emp.hire_date).getFullYear() !== filters.hireYear)
      return false;
    const age = computeAge(emp.birth_date, filters.asOf);
    if (filters.ageMax != null && age > filters.ageMax) return false;
    if (filters.ageMin != null && age < filters.ageMin) return false;
    return true;
  });
}

export interface OrgNode {
  key: string;
  label: string;
  level: "division" | "group" | "department";
  children: OrgNode[];
  members: Employee[];
}

export function buildOrgTree(employees: Employee[]): OrgNode[] {
  const divisions = new Map<string, OrgNode>();

  for (const emp of employees) {
    let division = divisions.get(emp.division);
    if (!division) {
      division = {
        key: emp.division,
        label: emp.division,
        level: "division",
        children: [],
        members: [],
      };
      divisions.set(emp.division, division);
    }

    if (emp.group_name) {
      let group = division.children.find(
        (c) => c.level === "group" && c.label === emp.group_name
      );
      if (!group) {
        group = {
          key: `${division.key}::group::${emp.group_name}`,
          label: emp.group_name,
          level: "group",
          children: [],
          members: [],
        };
        division.children.push(group);
      }
      let dept = group.children.find(
        (c) => c.level === "department" && c.label === emp.department
      );
      if (!dept) {
        dept = {
          key: `${group.key}::dept::${emp.department}`,
          label: emp.department,
          level: "department",
          children: [],
          members: [],
        };
        group.children.push(dept);
      }
      dept.members.push(emp);
    } else {
      let dept = division.children.find(
        (c) => c.level === "department" && c.label === emp.department
      );
      if (!dept) {
        dept = {
          key: `${division.key}::dept::${emp.department}`,
          label: emp.department,
          level: "department",
          children: [],
          members: [],
        };
        division.children.push(dept);
      }
      dept.members.push(emp);
    }
  }

  return Array.from(divisions.values());
}

export function getRecentHistory(limit = 200) {
  const db = getDb();
  return db
    .prepare(
      `SELECT * FROM employee_history ORDER BY snapshot_date DESC, id DESC LIMIT ?`
    )
    .all(limit);
}

export function getSnapshots() {
  const db = getDb();
  return db
    .prepare(`SELECT * FROM snapshots ORDER BY snapshot_date DESC`)
    .all();
}

export function getLatestSnapshotDate(): string | null {
  const db = getDb();
  const row = db
    .prepare(`SELECT snapshot_date FROM snapshots ORDER BY snapshot_date DESC LIMIT 1`)
    .get() as { snapshot_date: string } | undefined;
  return row?.snapshot_date ?? null;
}
