import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const DB_PATH = path.join(process.cwd(), "data", "app.db");

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (db) return db;

  const isNew = !fs.existsSync(DB_PATH);
  db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");

  db.exec(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      seq INTEGER,
      emp_no TEXT NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      division TEXT NOT NULL,
      group_name TEXT,
      department TEXT NOT NULL,
      title TEXT,
      birth_date TEXT NOT NULL,
      gender TEXT,
      hire_date TEXT NOT NULL,
      work_start_date TEXT,
      contract_end_date TEXT,
      regular_conversion_date TEXT,
      nationality TEXT,
      researcher_type TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      first_snapshot_date TEXT NOT NULL,
      last_snapshot_date TEXT NOT NULL,
      inactive_since TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(emp_no)
    );

    CREATE TABLE IF NOT EXISTS snapshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      snapshot_date TEXT NOT NULL UNIQUE,
      uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
      employee_count INTEGER NOT NULL,
      note TEXT
    );

    CREATE TABLE IF NOT EXISTS employee_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      emp_no TEXT NOT NULL,
      name TEXT NOT NULL,
      division TEXT NOT NULL,
      group_name TEXT,
      department TEXT NOT NULL,
      title TEXT,
      snapshot_date TEXT NOT NULL,
      change_type TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_employees_division ON employees(division, group_name, department);
    CREATE INDEX IF NOT EXISTS idx_employees_hire_date ON employees(hire_date);
    CREATE INDEX IF NOT EXISTS idx_history_snapshot ON employee_history(snapshot_date);
  `);

  if (isNew) {
    console.log("Initialized new SQLite DB at", DB_PATH);
  }

  return db;
}
