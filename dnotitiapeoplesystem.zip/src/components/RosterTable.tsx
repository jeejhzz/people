"use client";

export interface RosterRow {
  seq: number;
  emp_no: string;
  name: string;
  category: string;
  division: string;
  group_name: string | null;
  department: string;
  title: string | null;
  age: number;
  tenureYears: number;
  gender: string | null;
  hire_date: string;
  contract_end_date: string | null;
  researcher_type: string | null;
}

function toCsv(rows: RosterRow[]): string {
  const headers = [
    "번호",
    "사번",
    "이름",
    "분류",
    "상위조직1",
    "상위조직2",
    "부서",
    "직책",
    "나이(만)",
    "연차",
    "성별",
    "입사일",
    "계약종료일",
    "연구원",
  ];
  const lines = [headers.join(",")];
  for (const r of rows) {
    lines.push(
      [
        r.seq,
        r.emp_no,
        r.name,
        r.category,
        r.division,
        r.group_name ?? "",
        r.department,
        r.title ?? "",
        r.age,
        r.tenureYears,
        r.gender ?? "",
        r.hire_date,
        r.contract_end_date ?? "",
        r.researcher_type ?? "",
      ]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(",")
    );
  }
  return "﻿" + lines.join("\n");
}

export function downloadCsv(rows: RosterRow[], filename: string) {
  const blob = new Blob([toCsv(rows)], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function RosterTable({ rows }: { rows: RosterRow[] }) {
  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-neutral-300 p-8 text-center text-sm text-neutral-500">
        조건에 맞는 인원이 없습니다.
      </div>
    );
  }
  return (
    <div className="overflow-x-auto rounded-lg border border-neutral-200 bg-white">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-neutral-200 text-left text-xs text-neutral-500">
            <th className="px-3 py-2 font-medium">번호</th>
            <th className="px-3 py-2 font-medium">이름</th>
            <th className="px-3 py-2 font-medium">분류</th>
            <th className="px-3 py-2 font-medium">조직</th>
            <th className="px-3 py-2 font-medium">직책</th>
            <th className="px-3 py-2 font-medium text-right">나이(만)</th>
            <th className="px-3 py-2 font-medium text-right">연차</th>
            <th className="px-3 py-2 font-medium">성별</th>
            <th className="px-3 py-2 font-medium">입사일</th>
            <th className="px-3 py-2 font-medium">연구원</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.emp_no} className="border-b border-neutral-100 last:border-0 hover:bg-neutral-50">
              <td className="px-3 py-2 tabular-nums text-neutral-500">{r.seq}</td>
              <td className="px-3 py-2 font-medium">{r.name}</td>
              <td className="px-3 py-2">{r.category}</td>
              <td className="px-3 py-2 text-neutral-600">
                {[r.division, r.group_name, r.department].filter(Boolean).join(" · ")}
              </td>
              <td className="px-3 py-2 text-neutral-600">{r.title ?? "-"}</td>
              <td className="px-3 py-2 text-right tabular-nums">{r.age}</td>
              <td className="px-3 py-2 text-right tabular-nums">{r.tenureYears}</td>
              <td className="px-3 py-2">{r.gender ?? "-"}</td>
              <td className="px-3 py-2 tabular-nums">{r.hire_date}</td>
              <td className="px-3 py-2">{r.researcher_type ?? "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
