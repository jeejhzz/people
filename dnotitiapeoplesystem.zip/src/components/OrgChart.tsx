"use client";

interface OrgMember {
  emp_no: string;
  name: string;
  title: string | null;
  category: string;
  isRecentHire: boolean;
  isMoved: boolean;
  isIntern: boolean;
}

export interface OrgNodeData {
  key: string;
  label: string;
  level: "division" | "group" | "department";
  children: OrgNodeData[];
  members: OrgMember[];
}

const LEVEL_STYLES: Record<OrgNodeData["level"], string> = {
  division: "bg-violet-100 border-violet-300 text-violet-900",
  group: "bg-teal-100 border-teal-300 text-teal-900",
  department: "bg-orange-100 border-orange-300 text-orange-900",
};

function MemberChip({ m }: { m: OrgMember }) {
  const bg = m.isRecentHire
    ? "bg-emerald-100 border-emerald-300"
    : m.isMoved
    ? "bg-amber-100 border-amber-300"
    : "bg-white border-neutral-200";
  return (
    <div
      className={`px-2 py-1 rounded border text-xs whitespace-nowrap ${bg}`}
      title={[m.title, m.category].filter(Boolean).join(" · ")}
    >
      <span className={m.title ? "font-semibold" : ""}>{m.name}</span>
      {m.isIntern && <span className="text-neutral-500"> (인)</span>}
    </div>
  );
}

function DepartmentCard({ node }: { node: OrgNodeData }) {
  const leaders = node.members.filter((m) => m.title);
  const rest = node.members.filter((m) => !m.title);
  return (
    <div className="w-44 shrink-0 rounded-lg border border-neutral-200 bg-white overflow-hidden">
      <div className={`px-2.5 py-2 text-xs font-semibold border-b ${LEVEL_STYLES.department}`}>
        {node.label}
        <span className="ml-1 font-normal text-[11px] opacity-70">({node.members.length})</span>
      </div>
      <div className="p-2 flex flex-col gap-1">
        {leaders.map((m) => (
          <MemberChip key={m.emp_no} m={m} />
        ))}
        {rest.map((m) => (
          <MemberChip key={m.emp_no} m={m} />
        ))}
        {node.members.length === 0 && (
          <div className="text-[11px] text-neutral-400 px-1">인원 없음</div>
        )}
      </div>
    </div>
  );
}

function GroupBlock({ node }: { node: OrgNodeData }) {
  const depts = node.children.filter((c) => c.level === "department");
  return (
    <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-3 flex flex-col gap-2">
      <div className={`self-start px-3 py-1.5 rounded-md border text-sm font-semibold ${LEVEL_STYLES.group}`}>
        {node.label}
      </div>
      {node.members.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {node.members.map((m) => (
            <MemberChip key={m.emp_no} m={m} />
          ))}
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        {depts.map((d) => (
          <DepartmentCard key={d.key} node={d} />
        ))}
      </div>
    </div>
  );
}

function DivisionBlock({ node }: { node: OrgNodeData }) {
  const groups = node.children.filter((c) => c.level === "group");
  const directDepts = node.children.filter((c) => c.level === "department");
  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-4 flex flex-col gap-3 min-w-[280px]">
      <div className={`self-start px-3 py-1.5 rounded-md border text-sm font-bold ${LEVEL_STYLES.division}`}>
        {node.label}
      </div>
      {node.members.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {node.members.map((m) => (
            <MemberChip key={m.emp_no} m={m} />
          ))}
        </div>
      )}
      <div className="flex flex-col gap-3">
        {groups.map((g) => (
          <GroupBlock key={g.key} node={g} />
        ))}
        {directDepts.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {directDepts.map((d) => (
              <DepartmentCard key={d.key} node={d} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function OrgChart({ tree }: { tree: OrgNodeData[] }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-500">
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded bg-emerald-100 border border-emerald-300" />
          최근 2개월 신규입사
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded bg-amber-100 border border-amber-300" />
          최근 2개월 부서이동
        </span>
        <span>(인) = 인턴</span>
        <span>굵은 글씨 = 직책 보유자</span>
      </div>
      <div className="flex flex-col gap-4 overflow-x-auto pb-4">
        <div className="flex flex-wrap gap-4">
          {tree.map((division) => (
            <DivisionBlock key={division.key} node={division} />
          ))}
        </div>
      </div>
    </div>
  );
}
